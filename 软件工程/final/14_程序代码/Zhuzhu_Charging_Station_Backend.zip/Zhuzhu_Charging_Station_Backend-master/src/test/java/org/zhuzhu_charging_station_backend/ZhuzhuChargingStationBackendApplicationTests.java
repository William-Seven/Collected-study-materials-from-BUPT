package org.zhuzhu_charging_station_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZhuzhuChargingStationBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
