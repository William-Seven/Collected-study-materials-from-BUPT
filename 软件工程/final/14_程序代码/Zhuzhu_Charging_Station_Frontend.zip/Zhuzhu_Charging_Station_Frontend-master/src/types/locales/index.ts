export type Language = 'en-US' | 'zh-CN' | 'zh-TW'
