export interface OrderDetailModalProps {
  id?: string
  mode?: number
  chargeAmount?: number
}
