// 对于JS文件可以在此声明模块，防止TS找不到指定模块，编辑器报错
// 案例 declare module  'vue3-video-play';
declare module '@wangeditor/editor-for-vue';
declare module 'diff';