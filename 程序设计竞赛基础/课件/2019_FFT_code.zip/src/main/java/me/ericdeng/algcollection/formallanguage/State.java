package me.ericdeng.algcollection.formallanguage;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

@AllArgsConstructor
public class State {

    private static final Map<String, State> map = new ConcurrentHashMap<>();

    @Getter
    private String name;

    public static State get(String name) {
        return map.computeIfAbsent(name, State::new);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) return true;
        if (obj == null) { return false; }
        if (obj instanceof State) {
            return name.equals(((State) obj).name);
        }
        return false;
    }

    @Override
    public String toString() {
        return name;
    }

}
