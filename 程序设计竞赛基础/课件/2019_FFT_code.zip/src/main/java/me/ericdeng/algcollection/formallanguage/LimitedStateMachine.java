package me.ericdeng.algcollection.formallanguage;

import lombok.AllArgsConstructor;

import java.util.Map;
import java.util.Objects;

@AllArgsConstructor
public class LimitedStateMachine {

    private Map<TransferCondition, State> transferTable;

    private State initialState;

    private ActionPerformer actionPerformer;

    /**
     * analysis the input sequence and perform action when state changed, and check if the input sequence is accepted
     *
     * @param charSequence input
     * @return is the sequence accepted
     */
    public boolean analysis(CharSequence charSequence) {

        State state = initialState;
        char c;
        for (int i = 0; i < charSequence.length(); i++) {
            c = charSequence.charAt(i);
            State nextState = transferTable.get(TransferCondition.get(state, c));
            if (nextState != null) {
                actionPerformer.doAction(state, c);
                state = nextState;
            } else {
                nextState = transferTable.get(TransferCondition.get(state, Character.MIN_VALUE));
                if (nextState != null) {
                    actionPerformer.doAction(state, c);
                    state = nextState;
                } else {
                    boolean shouldContinue = actionPerformer.doError(state, c);
                    if (!shouldContinue) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    public interface ActionPerformer {

        /**
         * perform action in state machine running
         *
         * @param state current state
         * @param c     current input char
         */
        void doAction(State state, char c);

        /**
         * handle error in state machine running
         *
         * @param state current state
         * @param c     current input char
         * @return should the process continue
         */
        boolean doError(State state, char c);

    }

    public static class TransferCondition {

        private State state;

        private Character character;

        private TransferCondition(State state, Character character) {
            this.state = state;
            this.character = character;
        }

        public static TransferCondition get(State state, Character character) {
            return new TransferCondition(state, character);
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == this) { return true; }
            if (obj == null) { return false; }
            if (obj instanceof TransferCondition) {
                return state.equals(((TransferCondition) obj).state) &&
                    character.equals(((TransferCondition) obj).character);
            }
            return false;
        }

        @Override
        public int hashCode() {
            return Objects.hash(state, character);
        }

    }

}
