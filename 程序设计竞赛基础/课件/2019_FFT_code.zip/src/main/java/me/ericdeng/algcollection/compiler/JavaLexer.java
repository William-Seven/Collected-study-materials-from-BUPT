package me.ericdeng.algcollection.compiler;

import me.ericdeng.algcollection.formallanguage.LimitedStateMachine;

public class JavaLexer {
    LimitedStateMachine parser;
}
