package me.ericdeng.algcollection.formallanguage;

import lombok.extern.slf4j.Slf4j;
import me.ericdeng.algcollection.formallanguage.LimitedStateMachine.TransferCondition;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.util.HashMap;

@Slf4j
class LimitedStateMachineTest {

    private static LimitedStateMachine abcMachine;

    private static LimitedStateMachine.ActionPerformer logger = new LimitedStateMachine.ActionPerformer() {
        @Override
        public void doAction(State state, char c) {
            log.info("doAction: {}, {}", state, c);
        }

        @Override
        public boolean doError(State state, char c) {
            log.info("doError: {}, {}", state, c);
            return true;
        }
    };

    @BeforeAll
    static void setUp() {
        HashMap<TransferCondition, State> transferTable1 = new HashMap<>();
        State initial = new State("INITIAL");
        State q = new State("q");
        State p = new State("p");

        transferTable1.put(TransferCondition.get(initial, 'a'), q);
        transferTable1.put(TransferCondition.get(q, 'b'), p);
        transferTable1.put(TransferCondition.get(p, 'c'), initial);

        abcMachine = new LimitedStateMachine(transferTable1, initial, logger);
    }

    @Test
    void test() {
        abcMachine.analysis("abc");
    }

}